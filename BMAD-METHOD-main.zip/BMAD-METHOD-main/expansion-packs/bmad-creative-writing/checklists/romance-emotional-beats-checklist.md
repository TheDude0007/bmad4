<!-- Powered by BMAD™ Core -->

# ------------------------------------------------------------

# 12. Romance Emotional Beats Checklist

# ------------------------------------------------------------

---

checklist:
id: romance-emotional-beats-checklist
name: Romance Emotional Beats Checklist
description: Track essential emotional beats in romance arcs.
items:

- "[ ] Meet‑cute / inciting attraction"
- "[ ] Growing intimacy montage"
- "[ ] Midpoint commitment or confession moment"
- "[ ] Dark night of the soul / breakup"
- "[ ] Grand gesture or reconciliation"
- "[ ] HEA or HFN ending clear"
  ...
