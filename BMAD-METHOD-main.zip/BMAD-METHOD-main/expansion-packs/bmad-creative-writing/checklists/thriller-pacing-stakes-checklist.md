<!-- Powered by BMAD™ Core -->

# ------------------------------------------------------------

# 19. Thriller Pacing & Stakes Checklist

# ------------------------------------------------------------

---

checklist:
id: thriller-pacing-stakes-checklist
name: Thriller Pacing & Stakes Checklist
description: Keep readers on edge with tight pacing and escalating stakes.
items:

- "[ ] Inciting incident by 10% mark"
- "[ ] Ticking clock or deadline present"
- "[ ] Complications escalate danger every 3–4 chapters"
- "[ ] Protagonist setbacks increase tension"
- "[ ] Twist/reversal at midpoint"
- "[ ] Final confrontation resolves central threat"
  ...
