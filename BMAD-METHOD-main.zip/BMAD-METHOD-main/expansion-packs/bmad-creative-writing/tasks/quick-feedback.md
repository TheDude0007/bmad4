<!-- Powered by BMAD™ Core -->

# ------------------------------------------------------------

# 13. Quick Feedback (Serial)

# ------------------------------------------------------------

---

task:
id: quick-feedback
name: Quick Feedback (Serial)
description: Fast beta feedback focused on pacing and hooks.
persona_default: beta-reader
inputs:

- chapter-dialog.md
  steps:
- Use condensed beta-feedback-form.
  output: chapter-notes.md
  ...
