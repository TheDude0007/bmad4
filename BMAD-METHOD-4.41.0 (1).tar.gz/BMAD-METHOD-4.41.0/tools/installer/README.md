# BMad Method Installer

## Usage

```bash
# Interactive installation
npx bmad-method install
```
