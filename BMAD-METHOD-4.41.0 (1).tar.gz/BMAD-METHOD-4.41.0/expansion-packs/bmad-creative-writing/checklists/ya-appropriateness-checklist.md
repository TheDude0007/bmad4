<!-- Powered by BMAD™ Core -->

# ------------------------------------------------------------

# 20. YA Appropriateness Checklist

# ------------------------------------------------------------

---

checklist:
id: ya-appropriateness-checklist
name: Young Adult Content Appropriateness Checklist
description: Ensure themes, language, and content suit YA audience.
items:

- "[ ] Protagonist age 13–18 and driving action"
- "[ ] Themes of identity, friendship, coming‑of‑age present"
- "[ ] Romance handles consent and boundaries responsibly"
- "[ ] Violence and language within YA market norms"
- "[ ] No explicit sexual content beyond fade‑to‑black"
- "[ ] Hopeful or growth‑oriented ending"
  ...
